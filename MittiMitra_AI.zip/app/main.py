"""MittiMitra AI - FastAPI application.

Run:  uvicorn app.main:app --reload --port 8000
"""
from __future__ import annotations

import html
import uuid
from pathlib import Path

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from . import config, db
from .advisory import explainer
from .advisory.report import build_advisory
from .kb import kb
from .sarvam import SarvamError, client
from .soil.extract import extract_report
from .soil.schema import PARAM_META

app = FastAPI(title="MittiMitra AI", version="0.1.0",
              description="Voice-first soil report and agricultural advisory assistant.")

STATIC_DIR = Path(__file__).parent / "static"


@app.on_event("startup")
def _startup() -> None:
    db.init_db()


# ---------------------------------------------------------------- health ----
@app.get("/api/health")
def health():
    return {
        "status": "ok",
        "sarvam_configured": client.configured,
        "offline_mode": config.OFFLINE,
        "models": {"chat": config.CHAT_MODEL, "stt": config.STT_MODEL,
                   "tts": config.TTS_MODEL, "translate": config.TRANSLATE_MODEL},
        "kb_entries": len(kb.load_kb()["entries"]),
    }


@app.get("/api/languages")
def languages():
    return config.LANGUAGES


@app.get("/api/params")
def params():
    return PARAM_META


# ---------------------------------------------------------------- farmers ---
class FarmerIn(BaseModel):
    name: str
    phone: str = ""
    village: str = ""
    district: str = ""
    state: str = ""


@app.post("/api/farmers")
def create_farmer(f: FarmerIn):
    fid = db.create_farmer(f.name, f.phone, f.village, f.district, f.state)
    return {"farmer_id": fid, "farmer": db.get_farmer(fid)}


@app.get("/api/farmers")
def list_farmers():
    return db.list_farmers()


# ---------------------------------------------------------------- samples ---
@app.post("/api/samples/upload")
async def upload_sample(file: UploadFile = File(...), farmer_id: str = Form(""),
                        language: str = Form("en-IN")):
    raw = await file.read()
    if not raw:
        raise HTTPException(400, "Empty file")
    if len(raw) > 25 * 1024 * 1024:
        raise HTTPException(413, "File too large (max 25 MB)")
    ext = Path(file.filename or "report.pdf").suffix or ".pdf"
    stored = config.UPLOAD_DIR / f"{uuid.uuid4().hex[:10]}{ext}"
    stored.write_bytes(raw)

    extraction = extract_report(raw, file.filename or stored.name,
                               stored_path=str(stored), language=language)
    sid = db.create_sample(farmer_id, file.filename or stored.name, str(stored),
                           extraction, source_type=extraction["source_type"],
                           is_synthetic=extraction.get("is_synthetic", False))
    return {"sample_id": sid, "extraction": extraction}


@app.get("/api/samples")
def list_samples():
    return db.list_samples()


@app.get("/api/samples/{sid}")
def get_sample(sid: str):
    s = db.get_sample(sid)
    if not s:
        raise HTTPException(404, "sample not found")
    return s


class StatusIn(BaseModel):
    status: str
    note: str = ""


@app.post("/api/samples/{sid}/status")
def set_status(sid: str, body: StatusIn):
    if not db.get_sample(sid):
        raise HTTPException(404, "sample not found")
    db.set_sample_status(sid, body.status, body.note)
    return {"status_log": db.sample_status_log(sid)}


@app.get("/api/samples/{sid}/status")
def get_status(sid: str):
    return {"status_log": db.sample_status_log(sid)}


# --------------------------------------------------------------- advisory ---
class AdvisoryIn(BaseModel):
    sample_id: str
    crop: str = ""
    location: str = ""
    language: str = "hi-IN"
    use_llm: bool = True


@app.post("/api/advisory")
def make_advisory(body: AdvisoryIn):
    s = db.get_sample(body.sample_id)
    if not s:
        raise HTTPException(404, "sample not found")
    farmer = db.get_farmer(s.get("farmer_id") or "") if s.get("farmer_id") else None
    advisory = build_advisory(s["extraction"], body.crop or None, body.location or None,
                              body.language, farmer=farmer, use_llm=body.use_llm)
    db.save_advisory(body.sample_id, body.language, advisory)
    return advisory


# ------------------------------------------------------------------ voice ---
@app.post("/api/voice/stt")
async def voice_stt(audio: UploadFile = File(...), mode: str = Form("transcribe")):
    raw = await audio.read()
    try:
        text = client.stt(raw, filename=audio.filename or "audio.wav", mode=mode)
    except SarvamError as e:
        return JSONResponse({"error": f"STT unavailable ({e.status or 'error'})", "transcript": ""},
                            status_code=200)
    return {"transcript": text}


class TTSIn(BaseModel):
    text: str
    language: str = "hi-IN"
    speaker: str | None = None


@app.post("/api/voice/tts")
def voice_tts(body: TTSIn):
    try:
        audio = client.tts(body.text, language_code=body.language, speaker=body.speaker)
    except SarvamError as e:
        raise HTTPException(502, f"TTS unavailable ({e.status or 'error'})")
    if not audio:
        raise HTTPException(502, "TTS returned no audio")
    return Response(content=audio, media_type="audio/wav")


class AskIn(BaseModel):
    question: str
    sample_id: str = ""
    crop: str = ""
    location: str = ""
    language: str = "hi-IN"


@app.post("/api/ask")
def ask(body: AskIn):
    extraction = {}
    if body.sample_id:
        s = db.get_sample(body.sample_id)
        if s:
            extraction = s["extraction"]
    interp = {}
    if extraction:
        from .advisory.interpreter import interpret
        interp = interpret(extraction.get("values", {}), extraction.get("units", {}), body.crop or None)
    res = explainer.answer_question(body.question, extraction or {"values": {}, "units": {}, "validation": {"flags": []}},
                                    interp or {"findings": []}, body.crop or None, body.language,
                                    body.location or None)
    return res


# --------------------------------------------------------- printable report -
@app.get("/api/report/{sid}/print", response_class=HTMLResponse)
def printable(sid: str, language: str = "hi-IN"):
    s = db.get_sample(sid)
    if not s:
        raise HTTPException(404, "sample not found")
    adv = db.get_latest_advisory(sid)
    if not adv:
        raise HTTPException(409, "Generate the advisory first")
    a = adv["advisory"]
    ex = s["extraction"]
    farmer = db.get_farmer(s.get("farmer_id") or "") if s.get("farmer_id") else None

    def esc(x):
        return html.escape(str(x))

    rows = "".join(
        f"<tr><td>{esc(f['label_hi'] if language.startswith('hi') else f['label_en'])}</td>"
        f"<td>{esc(f['value'])} {esc(f['unit'])}</td>"
        f"<td>{esc(f['level_hi'] if language.startswith('hi') else f['level'])}</td></tr>"
        for f in a["findings"])
    srcs = "".join(f"<li>{esc(s['title'])} — {esc(s['org'])} ({s.get('year','')})</li>"
                   for s in a["sources"])
    lims = "".join(f"<li>{esc(x)}</li>" for x in a["limitations"])
    flag_rows = "".join(f"<li>{esc(fl['param'])}: {esc(fl['message'])}</li>"
                        for fl in ex.get("validation", {}).get("flags", []))
    banner = ("<p class='warn'>SYNTHETIC SAMPLE REPORT — demo data, not a real soil test.</p>"
              if a.get("is_synthetic") else "")

    doc = f"""<!doctype html><html><head><meta charset="utf-8">
<title>MittiMitra Report {esc(sid)}</title>
<style>
 body{{font-family:system-ui,Arial,sans-serif;max-width:780px;margin:24px auto;padding:0 16px;color:#111}}
 h1{{font-size:22px}} .muted{{color:#555;font-size:13px}} table{{border-collapse:collapse;width:100%;margin:12px 0}}
 th,td{{border:1px solid #ccc;padding:6px 8px;text-align:left;font-size:14px}}
 th{{background:#f3f3f3}} .warn{{background:#fff3cd;border:1px solid #e0c060;padding:8px;border-radius:6px}}
 .box{{background:#f8f8f8;border-radius:8px;padding:12px;margin:12px 0;white-space:pre-wrap}}
 @media print{{.noprint{{display:none}}}}
</style></head><body>
<h1>MittiMitra AI — Soil Report Explanation</h1>
<p class="muted">Sample: {esc(sid)} · Farmer: {esc(farmer['name']) if farmer else '—'} ·
Crop: {esc(a.get('crop') or '—')} · Location: {esc(a.get('location') or '—')} ·
Language: {esc(language)}</p>
{banner}
<h2>Extracted values</h2>
<table><tr><th>Parameter</th><th>Value</th><th>Status</th></tr>{rows}</table>
<h2>Explanation</h2><div class="box">{esc(a['explanation'])}</div>
<h2>Uncertain / missing values</h2><ul>{flag_rows or '<li>None</li>'}</ul>
<h2>Sources</h2><ul>{srcs}</ul>
<h2>Limitations</h2><ul>{lims}</ul>
<button class="noprint" onclick="window.print()">Print / Save as PDF</button>
</body></html>"""
    return HTMLResponse(doc)


# ------------------------------------------------------------------ static --
if STATIC_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


@app.get("/", response_class=HTMLResponse)
def index():
    idx = STATIC_DIR / "index.html"
    if idx.exists():
        return HTMLResponse(idx.read_text(encoding="utf-8"))
    return HTMLResponse("<h1>MittiMitra AI</h1><p>UI not built.</p>")
