"""SQLite persistence layer (a suitable lightweight database for the MVP).

Tables:
  farmers         - farmer/agent-entered identity and location
  samples         - an uploaded soil report + its extraction result (JSON)
  advisories      - generated advisory text/objects (JSON)
  sample_status   - laboratory sample lifecycle log
"""
from __future__ import annotations

import json
import sqlite3
import time
import uuid
from contextlib import contextmanager
from typing import Any

from . import config

_SCHEMA = """
CREATE TABLE IF NOT EXISTS farmers (
    id TEXT PRIMARY KEY,
    name TEXT,
    phone TEXT,
    village TEXT,
    district TEXT,
    state TEXT,
    created_at REAL
);
CREATE TABLE IF NOT EXISTS samples (
    id TEXT PRIMARY KEY,
    farmer_id TEXT,
    filename TEXT,
    stored_path TEXT,
    source_type TEXT,          -- 'pdf' | 'image' | 'synthetic'
    is_synthetic INTEGER DEFAULT 0,
    extraction_json TEXT,
    created_at REAL
);
CREATE TABLE IF NOT EXISTS advisories (
    id TEXT PRIMARY KEY,
    sample_id TEXT,
    language TEXT,
    advisory_json TEXT,
    created_at REAL
);
CREATE TABLE IF NOT EXISTS sample_status (
    id TEXT PRIMARY KEY,
    sample_id TEXT,
    status TEXT,
    note TEXT,
    at REAL
);
"""


@contextmanager
def _conn():
    con = sqlite3.connect(config.DB_PATH)
    con.row_factory = sqlite3.Row
    try:
        yield con
        con.commit()
    finally:
        con.close()


def init_db() -> None:
    with _conn() as con:
        con.executescript(_SCHEMA)


def _new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:10]}"


# --- farmers --------------------------------------------------------------
def create_farmer(name: str, phone: str = "", village: str = "", district: str = "",
                  state: str = "") -> str:
    fid = _new_id("farm")
    with _conn() as con:
        con.execute(
            "INSERT INTO farmers (id,name,phone,village,district,state,created_at) VALUES (?,?,?,?,?,?,?)",
            (fid, name, phone, village, district, state, time.time()),
        )
    return fid


def get_farmer(fid: str) -> dict | None:
    with _conn() as con:
        row = con.execute("SELECT * FROM farmers WHERE id=?", (fid,)).fetchone()
    return dict(row) if row else None


def list_farmers() -> list[dict]:
    with _conn() as con:
        rows = con.execute("SELECT * FROM farmers ORDER BY created_at DESC").fetchall()
    return [dict(r) for r in rows]


# --- samples --------------------------------------------------------------
def create_sample(farmer_id: str, filename: str, stored_path: str,
                  extraction: dict, source_type: str = "pdf",
                  is_synthetic: bool = False) -> str:
    sid = _new_id("smp")
    with _conn() as con:
        con.execute(
            "INSERT INTO samples (id,farmer_id,filename,stored_path,source_type,is_synthetic,"
            "extraction_json,created_at) VALUES (?,?,?,?,?,?,?,?)",
            (sid, farmer_id, filename, stored_path, source_type, int(is_synthetic),
             json.dumps(extraction), time.time()),
        )
        con.execute(
            "INSERT INTO sample_status (id,sample_id,status,note,at) VALUES (?,?,?,?,?)",
            (_new_id("st"), sid, "report_received", "Soil report uploaded and extracted", time.time()),
        )
    return sid


def get_sample(sid: str) -> dict | None:
    with _conn() as con:
        row = con.execute("SELECT * FROM samples WHERE id=?", (sid,)).fetchone()
    if not row:
        return None
    d = dict(row)
    d["extraction"] = json.loads(d.pop("extraction_json") or "{}")
    return d


def list_samples() -> list[dict]:
    with _conn() as con:
        rows = con.execute("SELECT id,farmer_id,filename,source_type,is_synthetic,created_at "
                           "FROM samples ORDER BY created_at DESC").fetchall()
    return [dict(r) for r in rows]


def set_sample_status(sid: str, status: str, note: str = "") -> None:
    with _conn() as con:
        con.execute(
            "INSERT INTO sample_status (id,sample_id,status,note,at) VALUES (?,?,?,?,?)",
            (_new_id("st"), sid, status, note, time.time()),
        )


def sample_status_log(sid: str) -> list[dict]:
    with _conn() as con:
        rows = con.execute("SELECT status,note,at FROM sample_status WHERE sample_id=? ORDER BY at", (sid,)).fetchall()
    return [dict(r) for r in rows]


# --- advisories -----------------------------------------------------------
def save_advisory(sample_id: str, language: str, advisory: dict) -> str:
    aid = _new_id("adv")
    with _conn() as con:
        con.execute(
            "INSERT INTO advisories (id,sample_id,language,advisory_json,created_at) VALUES (?,?,?,?,?)",
            (aid, sample_id, language, json.dumps(advisory, ensure_ascii=False), time.time()),
        )
    return aid


def get_latest_advisory(sample_id: str) -> dict | None:
    with _conn() as con:
        row = con.execute("SELECT * FROM advisories WHERE sample_id=? ORDER BY created_at DESC LIMIT 1",
                          (sample_id,)).fetchone()
    if not row:
        return None
    d = dict(row)
    d["advisory"] = json.loads(d.pop("advisory_json"))
    return d
