"""Rule-based interpretation of validated soil values.

Deterministic: it turns each value into a low/suitable/high status using the
bands in validators.py and attaches the relevant, source-linked knowledge-base
guidance. The language model is used later only to *phrase* this, never to
decide it.
"""
from __future__ import annotations

from ..kb import kb
from ..soil.schema import PARAM_META, PARAMS
from ..soil.validators import DEFICIENT, classify

# Map an internal band category to a farmer-facing level.
STATUS = {
    "strongly_acidic": "low", "acidic": "slightly_low", "neutral": "suitable",
    "alkaline": "high", "strongly_alkaline": "high",
    "normal": "suitable", "slightly_saline": "slightly_high",
    "moderately_saline": "high", "strongly_saline": "high",
    "low": "low", "medium": "suitable", "high": "high",
    "suitable_for_crop": "suitable", "outside_crop_window": "attention",
}

LEVEL_HI = {"low": "कम", "suitable": "उपयुक्त", "high": "अधिक",
            "slightly_low": "थोड़ा कम", "slightly_high": "थोड़ा अधिक",
            "attention": "ध्यान दें"}


def interpret(values: dict, units: dict, crop: str | None) -> dict:
    findings = []
    params_present = [p for p in PARAMS if p in values]

    for p in params_present:
        v = values[p]
        cls = classify(p, v, crop)
        cat = cls.get("category") or "unknown"
        level = STATUS.get(cat, "unknown")
        entries = kb.retrieve([p], crop=crop, limit=3)
        why = next((e["text_en"] for e in entries if e["params"]), "")
        action = next((e["text_en"] for e in entries if e["params"]), "")
        findings.append({
            "param": p,
            "label_en": PARAM_META[p]["en"],
            "label_hi": PARAM_META[p]["hi"],
            "value": v,
            "unit": units.get(p, PARAM_META[p]["unit"]),
            "category": cat,
            "level": level,
            "level_hi": LEVEL_HI.get(level, level),
            "crop_window": cls.get("crop_window"),
            "crop_match": cls.get("crop_match"),
            "why_it_matters": why,
            "action": action,
            "needs_attention": cat in DEFICIENT or level in ("low", "high", "attention"),
            "kb_ids": [e["id"] for e in entries],
            "sources": kb.sources_for(entries),
        })

    # Overall read-out
    low_nutrients = [f["param"] for f in findings if f["level"] == "low"]
    high_issues = [f["param"] for f in findings if f["level"] == "high"]
    ph_f = next((f for f in findings if f["param"] == "ph"), None)

    summary = {
        "n_params": len(findings),
        "low": low_nutrients,
        "high": high_issues,
        "ph_status": ph_f["category"] if ph_f else None,
        "needs_expert": bool(low_nutrients or high_issues) or (ph_f and ph_f["needs_attention"]),
    }
    return {"findings": findings, "summary": summary}
