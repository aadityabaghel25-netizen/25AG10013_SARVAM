"""Assemble the final advisory object returned to the UI and stored in the DB."""
from __future__ import annotations

import time

from ..kb import kb
from . import explainer
from .interpreter import interpret

LIMITATIONS = [
    "This explanation uses only the values extracted from your uploaded report and general "
    "public agricultural guidance. It is not a soil-test based fertiliser prescription.",
    "It does not prescribe fertiliser or pesticide doses. Follow the dose printed on your "
    "Soil Health Card or the recommendation of your State Agriculture Department / KVK.",
    "If any value was missing, unreadable or flagged, it was not used and is listed as uncertain.",
    "The reference ranges are general (crop-specific where noted) and may differ by region.",
]


def build_advisory(extraction: dict, crop: str | None, location: str | None,
                   language: str, farmer: dict | None = None,
                   use_llm: bool = True) -> dict:
    values = extraction.get("values", {})
    units = extraction.get("units", {})
    interp = interpret(values, units, crop)

    if use_llm:
        text_en = explainer.generate_english(extraction, interp, farmer, crop, location)
    else:
        text_en = explainer._template_english(extraction, interp, crop, location)

    localized = explainer.localize(text_en, language)

    # Short spoken summary (kept under the TTS char cap).
    s = interp["summary"]
    if s["low"]:
        spoken_en = (f"Soil report summary for your {crop or 'crop'}. "
                     f"Your soil is low in {', '.join(s['low'])}. "
                     f"Please read the details and consult your KVK for doses.")
    else:
        spoken_en = (f"Soil report summary for your {crop or 'crop'}. "
                     f"No major nutrient shortage was found in the measured values. "
                     f"Please consult your KVK for field-specific advice.")
    spoken = explainer.localize(spoken_en, language)

    entries = kb.retrieve([f["param"] for f in interp["findings"]], crop=crop, limit=8)
    sources = kb.sources_for(entries)

    return {
        "generated_at": time.time(),
        "language": language,
        "crop": crop,
        "location": location,
        "findings": interp["findings"],
        "summary": s,
        "explanation_en": text_en,
        "explanation": localized["text"],
        "translated": localized.get("translated", False),
        "translation_error": localized.get("error"),
        "spoken_summary": spoken["text"],
        "sources": sources,
        "kb_ids": [e["id"] for e in entries],
        "limitations": LIMITATIONS,
        "printed_recommendation": extraction.get("printed_recommendation", ""),
        "is_synthetic": extraction.get("is_synthetic", False),
        "extraction_methods": extraction.get("methods", []),
        "validation": extraction.get("validation", {}),
    }
