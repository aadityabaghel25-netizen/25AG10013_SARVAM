"""Grounded, multilingual explanation generation.

Design rule: the language model is given the extracted numbers and the
source-linked knowledge-base snippets as its ONLY facts. It is explicitly
forbidden from inventing measurements or fertiliser/pesticide doses. Output is
generated in English and then translated with Sarvam Translate, which keeps
numbers, units and chemical names intact across languages.
"""
from __future__ import annotations

from .. import config
from ..kb import kb
from ..sarvam import SarvamError, client
from ..soil.schema import PARAM_META

SYSTEM = (
    "You are MittiMitra, a careful agricultural advisor for smallholder farmers in India. "
    "You explain a soil test report in simple, respectful language. "
    "STRICT RULES: (1) Use ONLY the soil values and the guidance snippets provided to you. "
    "(2) NEVER invent a soil measurement, a number, or a fertiliser/pesticide dose that is not "
    "in the provided data. (3) If a value is missing or uncertain, say clearly that it is not "
    "available or needs checking. (4) Keep sentences short and avoid technical jargon. "
    "(5) Do not diagnose a disease. (6) Where you give an action, mention the source it came from. "
    "(7) End by telling the farmer to consult their local KVK or agriculture officer for "
    "field-specific doses."
)


def _facts_block(extraction: dict, interp: dict, farmer: dict | None, crop: str | None,
                 location: str | None) -> str:
    vals = extraction.get("values", {})
    units = extraction.get("units", {})
    lines = []
    for f in interp["findings"]:
        lines.append(f"- {f['label_en']}: {f['value']} {f['unit']} -> status: {f['level']} "
                     f"(band: {f['category']})")
    missing = [PARAM_META[p]["en"] for p in extraction.get("validation", {}).get("flags", [])
               if False]
    flags = extraction.get("validation", {}).get("flags", [])
    flag_txt = "\n".join(f"- {fl['param']}: {fl['message']}" for fl in flags) or "- none"

    kb_lines = []
    for f in interp["findings"]:
        for e in kb.retrieve([f["param"]], crop=crop, limit=1):
            src = e.get("source_record", {}).get("org", "source")
            kb_lines.append(f"- [{f['label_en']}] {e['text_en']} (Source: {src})")
    kb_txt = "\n".join(dict.fromkeys(kb_lines)) or "- none"

    printed = extraction.get("printed_recommendation") or "(none printed on the report)"

    return (
        f"FARMER CONTEXT: name={farmer.get('name') if farmer else 'unknown'}, "
        f"crop={crop or 'not given'}, location={location or 'not given'}.\n\n"
        f"EXTRACTED SOIL VALUES (the only numbers you may use):\n" + "\n".join(lines) + "\n\n"
        f"UNCERTAINTIES / MISSING VALUES:\n{flag_txt}\n\n"
        f"FERTILISER DOSE PRINTED ON THE REPORT (quote only, do not alter): {printed}\n\n"
        f"APPROVED GUIDANCE SNIPPETS:\n{kb_txt}\n"
    )


def generate_english(extraction: dict, interp: dict, farmer: dict | None = None,
                     crop: str | None = None, location: str | None = None) -> str:
    facts = _facts_block(extraction, interp, farmer, crop, location)
    user = (
        "Explain this soil report to the farmer. Structure it as: "
        "a one-line summary; then for each parameter say what it measures, what their value means "
        "(low / suitable / high), why it matters for their crop, and the supported action if any; "
        "then a short 'what to do next' list; then the sources; then a limitations line. "
        "Write in plain English, short sentences.\n\n" + facts
    )
    if client.configured:
        try:
            # Generous budget: the reasoning model consumes tokens before emitting content.
            txt = client.chat([{"role": "system", "content": SYSTEM},
                               {"role": "user", "content": user}],
                              temperature=0.2, max_tokens=4000)
            if txt:
                return txt
        except SarvamError:
            pass
    return _template_english(extraction, interp, crop, location)


def _template_english(extraction: dict, interp: dict, crop: str | None,
                      location: str | None) -> str:
    """Deterministic fallback used when the LLM is unavailable."""
    out = []
    s = interp["summary"]
    if s["low"]:
        out.append(f"Your soil is low in: {', '.join(s['low'])}. "
                   f"Some nutrients need attention.")
    else:
        out.append("Your soil test shows no major nutrient shortage in the values measured.")
    if s.get("ph_status"):
        out.append(f"Soil pH is in the '{s['ph_status']}' range.")
    out.append("")
    for f in interp["findings"]:
        out.append(f"{f['label_en']}: {f['value']} {f['unit']} — {f['level']} for your crop.")
        if f["why_it_matters"]:
            out.append("  Why it matters: " + f["why_it_matters"])
        if f["needs_attention"] and f["action"]:
            out.append("  Suggested action: " + f["action"])
    out.append("")
    out.append("Please consult your local KVK or agriculture officer for field-specific doses.")
    out.append("Limitations: this explanation uses only the values extracted from the report and "
               "general public guidance; it is not a substitute for a soil-test based recommendation.")
    return "\n".join(out)


def localize(text_en: str, target: str) -> dict:
    """Translate to the target language. Returns {text, language, translated:bool}."""
    if not target or target == "en-IN":
        return {"text": text_en, "language": "en-IN", "translated": False}
    if client.configured:
        try:
            return {"text": client.translate(text_en, target, source="en-IN"),
                    "language": target, "translated": True}
        except SarvamError as e:
            return {"text": text_en, "language": "en-IN", "translated": False,
                    "error": f"translation unavailable ({e.status or 'error'})"}
    return {"text": text_en, "language": "en-IN", "translated": False,
            "error": "offline: translation unavailable"}


def answer_question(question: str, extraction: dict, interp: dict, crop: str | None,
                    target: str, location: str | None = None) -> dict:
    """Answer a spoken/typed follow-up, grounded in the same facts."""
    facts = _facts_block(extraction, interp, None, crop, location)
    if client.configured:
        try:
            ans = client.chat([
                {"role": "system", "content": SYSTEM},
                {"role": "user", "content": f"{facts}\n\nFARMER'S QUESTION: {question}\n"
                                            "Answer briefly (2-4 short sentences). You may use the "
                                            "APPROVED GUIDANCE SNIPPETS above to suggest an action. "
                                            "If the answer is not in the provided data, say so."}],
                temperature=0.2, max_tokens=2500)
            if not ans:
                ans = ("I can answer only from the extracted report values. Please try rephrasing, "
                       "or consult your KVK.")
        except SarvamError:
            ans = ("I can only answer from the extracted report values, and the assistant is "
                   "temporarily unavailable. Please try again or ask your KVK.")
    else:
        ans = ("The assistant is running offline, so I cannot answer free-form questions right "
               "now. The parameter explanations above are still valid.")
    loc = localize(ans, target)
    return {"answer_en": ans, **loc}
