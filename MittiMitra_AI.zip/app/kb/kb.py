"""Small, transparent knowledge-base retrieval.

Retrieval is keyword/parameter based (no embeddings) so that every returned
snippet is traceable to a numbered entry and a source record. This keeps the
advisory auditable and prevents the language model from drawing on unverified
knowledge.
"""
from __future__ import annotations

import json
from functools import lru_cache

from .. import config


@lru_cache(maxsize=1)
def load_kb() -> dict:
    data = json.loads(config.KB_PATH.read_text(encoding="utf-8"))
    src = {s["id"]: s for s in data["meta"]["sources"]}
    for e in data["entries"]:
        e["source_record"] = src.get(e["source"], {})
    return data


def sources() -> dict:
    return {s["id"]: s for s in load_kb()["meta"]["sources"]}


def retrieve(params: list[str], crop: str | None = None, category: str | None = None,
             limit: int = 6) -> list[dict]:
    """Return KB entries relevant to the given parameters/crop.

    Scoring: +3 for a matching parameter, +2 for a crop match, +1 for category,
    +1 for a general entry. Deterministic and reproducible.
    """
    kb = load_kb()
    crop_l = (crop or "").lower()
    scored = []
    for e in kb["entries"]:
        score = 0
        if e["params"] and set(e["params"]) & set(params):
            score += 3
        if e["crops"] and crop_l and any(c in crop_l for c in e["crops"]):
            score += 2
        if e["crops"] and not crop_l:
            score -= 1  # crop-specific entry without a known crop
        if category and e.get("category") == category:
            score += 1
        if not e["params"] and not e["crops"]:
            score += 1  # general guidance is usually safe to include
        if score > 0:
            scored.append((score, e))
    scored.sort(key=lambda t: (-t[0], t[1]["id"]))
    return [e for _, e in scored[:limit]]


def sources_for(entries: list[dict]) -> list[dict]:
    seen, out = set(), []
    for e in entries:
        s = e.get("source_record") or {}
        if s and s["id"] not in seen:
            seen.add(s["id"])
            out.append(s)
    return out
