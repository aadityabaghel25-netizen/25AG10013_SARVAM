"""Thin, dependency-light client for the Sarvam AI REST APIs.

Endpoints and model IDs were verified live against https://docs.sarvam.ai
(see docs/ARCHITECTURE.md for the verification log):

  * Chat            POST /v1/chat/completions          model: sarvam-105b
  * Speech-to-text  POST /speech-to-text               model: saaras:v4
  * Text-to-speech  POST /text-to-speech               model: bulbul:v3
  * Translation     POST /translate                    model: mayura:v1
  * Document AI     POST /doc-ai/v1/job/digitise
                    POST /doc-ai/v1/job/extract
                    GET  /doc-ai/v1/job/{id}/status
                    GET  /doc-ai/v1/job/{id}/results

Auth header: `api-subscription-key`.
"""
from __future__ import annotations

import base64
import gzip
import json
import time
from dataclasses import dataclass
from typing import Any

import httpx

from . import config


class SarvamError(RuntimeError):
    """Raised when a Sarvam API call fails. Carries an HTTP-ish status."""

    def __init__(self, message: str, status: int | None = None, body: str | None = None):
        super().__init__(message)
        self.status = status
        self.body = body


@dataclass
class DocResult:
    result: dict[str, Any]
    annotations: dict[str, Any]
    usage: dict[str, Any]


class SarvamClient:
    def __init__(self, api_key: str | None = None, base_url: str | None = None, timeout: float = 90.0):
        self.api_key = api_key or config.SARVAM_API_KEY
        self.base_url = (base_url or config.SARVAM_BASE_URL).rstrip("/")
        self.timeout = timeout

    # -- internals ---------------------------------------------------------
    @property
    def configured(self) -> bool:
        return bool(self.api_key) and not config.OFFLINE

    def _headers(self, json_body: bool = True) -> dict[str, str]:
        h = {"api-subscription-key": self.api_key}
        if json_body:
            h["Content-Type"] = "application/json"
        return h

    def _check(self, r: httpx.Response) -> None:
        if r.status_code >= 400:
            raise SarvamError(
                f"Sarvam API error {r.status_code}", status=r.status_code, body=r.text[:500]
            )

    # -- chat --------------------------------------------------------------
    def chat(self, messages: list[dict], model: str | None = None,
             temperature: float = 0.2, max_tokens: int = 1024) -> str:
        if not self.configured:
            raise SarvamError("Sarvam not configured (no key or offline mode)")
        payload = {
            "model": model or config.CHAT_MODEL,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        with httpx.Client(timeout=self.timeout) as c:
            r = c.post(f"{self.base_url}/v1/chat/completions",
                       headers=self._headers(), json=payload)
        self._check(r)
        data = r.json()
        msg = data["choices"][0]["message"]
        # sarvam-105b is a reasoning model: content can be empty when the token
        # budget is exhausted by reasoning. Return "" so callers fall back.
        return (msg.get("content") or "").strip()

    # -- translation -------------------------------------------------------
    def translate(self, text: str, target: str, source: str = "auto",
                  model: str | None = None) -> str:
        """Translate. Chunks long text to respect the API's per-request cap."""
        if not self.configured:
            raise SarvamError("Sarvam not configured (no key or offline mode)")
        model = model or config.TRANSLATE_MODEL
        limit = 1000 if model == "mayura:v1" else 2000
        out: list[str] = []
        for chunk in _chunks(text, limit):
            payload = {
                "input": chunk,
                "source_language_code": source,
                "target_language_code": target,
                "model": model,
            }
            with httpx.Client(timeout=self.timeout) as c:
                r = c.post(f"{self.base_url}/translate", headers=self._headers(), json=payload)
            self._check(r)
            out.append(r.json().get("translated_text", ""))
        return " ".join(out)

    # -- text to speech ----------------------------------------------------
    def tts(self, text: str, language_code: str = "hi-IN", speaker: str | None = None,
            model: str | None = None, sample_rate: int = 22050) -> bytes:
        if not self.configured:
            raise SarvamError("Sarvam not configured (no key or offline mode)")
        # Bulbul rejects very long text; keep each call modest.
        text = text[:490]
        payload = {
            "text": text,
            "language_code": language_code,
            "model": model or config.TTS_MODEL,
            "speech_sample_rate": sample_rate,
        }
        sp = speaker or config.TTS_SPEAKER
        if sp:
            payload["speaker"] = sp
        with httpx.Client(timeout=self.timeout) as c:
            r = c.post(f"{self.base_url}/text-to-speech", headers=self._headers(), json=payload)
        self._check(r)
        audios = r.json().get("audios", [])
        return base64.b64decode("".join(audios)) if audios else b""

    # -- speech to text ----------------------------------------------------
    def stt(self, audio: bytes, filename: str = "audio.wav", mode: str = "transcribe",
            model: str | None = None) -> str:
        if not self.configured:
            raise SarvamError("Sarvam not configured (no key or offline mode)")
        files = {"file": (filename, audio, "audio/wav")}
        data = {"model": model or config.STT_MODEL, "mode": mode}
        with httpx.Client(timeout=self.timeout) as c:
            r = c.post(f"{self.base_url}/speech-to-text", headers=self._headers(json_body=False),
                       files=files, data=data)
        self._check(r)
        j = r.json()
        return j.get("transcript") or j.get("text") or ""

    # -- document AI -------------------------------------------------------
    def doc_digitise(self, file_bytes: bytes, filename: str, language: str = "en-IN",
                     output_format: str = "md", poll_seconds: float = 5.0,
                     max_wait: float = 180.0) -> str:
        """Full-document OCR. Returns the primary digitised text/markdown."""
        job_id = self._doc_start("digitise", file_bytes, filename,
                                 {"language": language, "output_format": output_format})
        self._doc_wait(job_id, poll_seconds, max_wait)
        return self._doc_primary_text(job_id)

    def doc_extract(self, file_bytes: bytes, filename: str, schema: dict,
                    language: str = "en-IN", poll_seconds: float = 5.0,
                    max_wait: float = 180.0) -> DocResult:
        """Schema-based key-value extraction with per-field confidence."""
        job_id = self._doc_start("extract", file_bytes, filename,
                                 {"language": language, "output_format": "json"},
                                 extra={"schema": json.dumps(schema)})
        self._doc_wait(job_id, poll_seconds, max_wait)
        with httpx.Client(timeout=self.timeout) as c:
            r = c.get(f"{self.base_url}/doc-ai/v1/job/{job_id}/results",
                      headers={**self._headers(False), "Accept-Encoding": "gzip"})
        self._check(r)
        raw = r.content
        try:
            data = json.loads(raw)
        except Exception:
            data = json.loads(gzip.decompress(raw))
        return DocResult(result=data.get("result", {}) or {},
                         annotations=data.get("annotations", {}) or {},
                         usage=data.get("usage", {}) or {})

    def _doc_start(self, pipeline: str, file_bytes: bytes, filename: str,
                   params: dict, extra: dict | None = None) -> str:
        if not self.configured:
            raise SarvamError("Sarvam not configured (no key or offline mode)")
        data = dict(params)
        if extra:
            data.update(extra)
        files = {"file": (filename, file_bytes, _mime(filename))}
        with httpx.Client(timeout=self.timeout) as c:
            r = c.post(f"{self.base_url}/doc-ai/v1/job/{pipeline}",
                       headers=self._headers(json_body=False), files=files, data=data)
        self._check(r)
        return r.json()["job_id"]

    def _doc_wait(self, job_id: str, poll: float, max_wait: float) -> str:
        terminal = {"completed", "partially_completed", "failed", "rejected"}
        deadline = time.time() + max_wait
        status = "pending"
        while time.time() < deadline:
            with httpx.Client(timeout=self.timeout) as c:
                r = c.get(f"{self.base_url}/doc-ai/v1/job/{job_id}/status", headers=self._headers(False))
            self._check(r)
            status = (r.json().get("status") or "").lower()
            if status in terminal:
                break
            time.sleep(poll)
        if status in ("failed", "rejected"):
            raise SarvamError(f"Document AI job {status}", body=job_id)
        return status

    def _doc_primary_text(self, job_id: str) -> str:
        with httpx.Client(timeout=self.timeout) as c:
            r = c.get(f"{self.base_url}/doc-ai/v1/job/{job_id}/download-url", headers=self._headers(False))
        self._check(r)
        url = r.json()["url"]
        with httpx.Client(timeout=self.timeout, follow_redirects=True) as c:
            z = c.get(url)
        self._check(z)
        import io
        import zipfile
        with zipfile.ZipFile(io.BytesIO(z.content)) as zf:
            names = [n for n in zf.namelist() if n.lower().endswith((".md", ".html", ".txt", ".json"))]
            md = [n for n in names if n.lower().endswith(".md")]
            pick = (md or names)
            if not pick:
                return ""
            return zf.read(pick[0]).decode("utf-8", "replace")


def _chunks(text: str, size: int) -> list[str]:
    """Split on sentence/word boundaries so translation stays coherent."""
    if len(text) <= size:
        return [text]
    chunks, cur = [], ""
    for piece in text.replace("\n", " \n ").split(" "):
        if len(cur) + len(piece) + 1 > size:
            chunks.append(cur.strip())
            cur = piece
        else:
            cur += " " + piece
    if cur.strip():
        chunks.append(cur.strip())
    return chunks


def _mime(filename: str) -> str:
    f = filename.lower()
    if f.endswith(".pdf"):
        return "application/pdf"
    if f.endswith(".png"):
        return "image/png"
    if f.endswith((".jpg", ".jpeg")):
        return "image/jpeg"
    if f.endswith(".zip"):
        return "application/zip"
    return "application/octet-stream"


# Module-level default client
client = SarvamClient()
