"""MittiMitra AI application package."""
