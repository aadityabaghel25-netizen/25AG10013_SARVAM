"""Deterministic agricultural validation rules.

This module is the single source of truth for "is this value low, suitable or
high". It contains NO language-model calls: the LLM is never allowed to decide
a soil category or invent a number.

Reference ranges follow the general interpretation bands used on Soil Health
Cards and ICAR/KVK soil-testing guidance (see app/kb/data/knowledge_base.json
for the source records). They are indicative general bands; crop-specific
windows, where known, override the general pH window.
"""
from __future__ import annotations

from .schema import PARAMS, PLAUSIBLE

# --- general reference bands ---------------------------------------------
# Each entry: list of (lo, hi, category). Bands are inclusive of lo, exclusive of hi.
GENERAL_BANDS: dict[str, list[tuple[float, float, str]]] = {
    "ph": [
        (0.0, 5.5, "strongly_acidic"),
        (5.5, 6.5, "acidic"),
        (6.5, 7.5, "neutral"),
        (7.5, 8.5, "alkaline"),
        (8.5, 14.0, "strongly_alkaline"),
    ],
    "ec": [
        (0.0, 1.0, "normal"),
        (1.0, 2.0, "slightly_saline"),
        (2.0, 4.0, "moderately_saline"),
        (4.0, 100.0, "strongly_saline"),
    ],
    "organic_carbon": [
        (0.0, 0.5, "low"),
        (0.5, 0.75, "medium"),
        (0.75, 100.0, "high"),
    ],
    "nitrogen": [
        (0.0, 280.0, "low"),
        (280.0, 560.0, "medium"),
        (560.0, 100000.0, "high"),
    ],
    "phosphorus": [
        (0.0, 10.0, "low"),
        (10.0, 25.0, "medium"),
        (25.0, 100000.0, "high"),
    ],
    "potassium": [
        (0.0, 120.0, "low"),
        (120.0, 280.0, "medium"),
        (280.0, 100000.0, "high"),
    ],
    "sulphur": [
        (0.0, 10.0, "low"),
        (10.0, 20.0, "medium"),
        (20.0, 100000.0, "high"),
    ],
    "zinc": [
        (0.0, 0.6, "low"),
        (0.6, 1.2, "medium"),
        (1.2, 100000.0, "high"),
    ],
    "iron": [(0.0, 4.5, "low"), (4.5, 9.0, "medium"), (9.0, 100000.0, "high")],
    "copper": [(0.0, 0.2, "low"), (0.2, 0.5, "medium"), (0.5, 100000.0, "high")],
    "manganese": [(0.0, 2.0, "low"), (2.0, 5.0, "medium"), (5.0, 100000.0, "high")],
    "boron": [(0.0, 0.5, "low"), (0.5, 1.0, "medium"), (1.0, 100000.0, "high")],
}

# Which categories mean "action likely needed" for a nutrient.
DEFICIENT = {"low", "strongly_acidic", "strongly_alkaline", "moderately_saline", "strongly_saline"}

# Crop-specific pH preference windows (best-available general guidance).
CROP_PH = {
    "paddy": (5.5, 6.5), "rice": (5.5, 6.5),
    "wheat": (6.0, 7.5),
    "maize": (5.5, 7.5), "corn": (5.5, 7.5),
    "cotton": (6.0, 8.0),
    "sugarcane": (6.0, 7.5),
    "groundnut": (6.0, 6.5), "peanut": (6.0, 6.5),
    "soybean": (6.0, 7.0),
    "gram": (6.0, 7.5), "chickpea": (6.0, 7.5), "pulse": (6.0, 7.5), "pulses": (6.0, 7.5),
    "mustard": (6.0, 7.5),
    "potato": (5.5, 6.5),
    "tomato": (6.0, 6.8),
    "onion": (6.0, 7.0),
    "chilli": (6.0, 7.0), "chili": (6.0, 7.0),
    "banana": (6.0, 7.5),
    "millet": (6.0, 7.5), "bajra": (6.5, 8.0), "jowar": (6.0, 7.5), "sorghum": (6.0, 7.5),
}


def crop_ph_window(crop: str | None) -> tuple[float, float] | None:
    if not crop:
        return None
    c = crop.lower()
    for key, window in CROP_PH.items():
        if key in c:
            return window
    return None


def _band(value: float, bands: list[tuple[float, float, str]]) -> str:
    for lo, hi, cat in bands:
        if lo <= value < hi:
            return cat
    return bands[-1][2]


def classify(param: str, value: float, crop: str | None = None) -> dict:
    """Return the category and whether the value is inside a crop-specific window."""
    out: dict = {"param": param, "value": value, "category": None, "crop_window": None}
    if param == "ph":
        window = crop_ph_window(crop)
        out["crop_window"] = window
        if window:
            lo, hi = window
            if lo <= value <= hi:
                out["category"] = "suitable_for_crop"
                out["crop_match"] = True
            else:
                # keep the general band too, but note the crop mismatch
                out["category"] = "outside_crop_window"
                out["crop_match"] = False
                out["general_category"] = _band(value, GENERAL_BANDS["ph"])
            return out
    bands = GENERAL_BANDS.get(param)
    if bands:
        out["category"] = _band(value, bands)
    return out


def plausibility(param: str, value: float) -> tuple[bool, str | None]:
    """Return (ok, reason). A value outside the physical range is rejected."""
    lo, hi = PLAUSIBLE.get(param, (float("-inf"), float("inf")))
    if value < lo or value > hi:
        return False, f"{param}={value} outside plausible range [{lo}, {hi}]"
    return True, None


def validate_extraction(extraction: dict) -> dict:
    """Apply validation rules to a raw extraction.

    Returns {values, flags, summary}. `values` holds only plausible, present
    numbers. Every problem is recorded in `flags` so the UI can show it.
    """
    values: dict[str, float] = {}
    flags: list[dict] = []
    raw = extraction.get("values", {}) or {}

    for p in PARAMS:
        v = raw.get(p)
        if v is None:
            flags.append({"param": p, "level": "missing",
                          "message": "Value not found in the report."})
            continue
        try:
            fv = float(v)
        except (TypeError, ValueError):
            flags.append({"param": p, "level": "unreadable",
                          "message": f"Could not read a number for {p}."})
            continue
        ok, reason = plausibility(p, fv)
        if not ok:
            flags.append({"param": p, "level": "implausible",
                          "message": f"Value looks physically impossible ({reason}). Needs manual check."})
            continue
        values[p] = fv

    # Confidence-based flags from Sarvam Vision annotations (only for values we kept).
    for p, ann in (extraction.get("confidence", {}) or {}).items():
        if p not in values:
            continue
        conf = ann.get("confidence") if isinstance(ann, dict) else ann
        if conf is not None and conf < 0.7:
            flags.append({"param": p, "level": "low_confidence",
                          "message": f"Extraction confidence {conf:.0%} — please verify against the report."})

    core = ["ph", "ec", "organic_carbon", "nitrogen", "phosphorus", "potassium"]
    have_core = [c for c in core if c in values]
    summary = {
        "core_present": len(have_core),
        "core_total": len(core),
        "complete": len(have_core) == len(core),
        "n_flags": len(flags),
    }
    return {"values": values, "flags": flags, "summary": summary}
