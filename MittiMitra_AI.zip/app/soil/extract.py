"""Extraction orchestration: turn an uploaded report into validated values.

Pipeline (each step degrades gracefully and is labelled in the output):

  1. Sarvam Vision `extract`  -> structured values + per-field confidence + page source
  2. Sarvam Vision `digitise` -> full text -> deterministic parse (units, metadata,
                                 printed recommendation, cross-check of values)
  3. Local pdfplumber text    -> offline fallback for text-layer PDFs only

Disagreements between (1) and (2) are surfaced as flags, never silently resolved
towards the model. Missing values are never invented.
"""
from __future__ import annotations

from .. import config
from ..sarvam import SarvamError, client
from .parse import local_pdf_text, parse_digitised
from .schema import EXTRACTION_SCHEMA, PARAMS, PARAM_META
from .validators import validate_extraction


def _detect_source(filename: str) -> str:
    f = filename.lower()
    if f.endswith(".pdf"):
        return "pdf"
    if f.endswith((".png", ".jpg", ".jpeg")):
        return "image"
    return "other"


def _is_synthetic(text: str, filename: str) -> bool:
    t = (text or "").lower()
    return "synthetic" in t or "syn-" in filename.lower()


def extract_report(file_bytes: bytes, filename: str, stored_path: str | None = None,
                   language: str = "en-IN") -> dict:
    """Return a full extraction object ready for storage and validation."""
    source_type = _detect_source(filename)
    method: list[str] = []
    notes: list[str] = []
    vision_values: dict[str, float] = {}
    confidence: dict[str, dict] = {}
    digitised_text = ""
    parsed: dict = {}

    # --- 1. Sarvam Vision schema extraction ---------------------------
    if client.configured:
        try:
            dr = client.doc_extract(file_bytes, filename, EXTRACTION_SCHEMA, language=language)
            method.append("sarvam_vision_extract")
            for k, v in (dr.result or {}).items():
                if k in PARAMS and isinstance(v, (int, float)):
                    vision_values[k] = float(v)
            confidence = dr.annotations or {}
        except SarvamError as e:
            notes.append(f"Vision extract unavailable ({e.status or 'error'}); fell back to OCR text parse.")
    else:
        notes.append("Sarvam offline: using local text extraction only.")

    # --- 2. Sarvam Vision digitise + parse ----------------------------
    if client.configured:
        try:
            digitised_text = client.doc_digitise(file_bytes, filename, language=language,
                                                 output_format="md")
            method.append("sarvam_vision_digitise")
            parsed = parse_digitised(digitised_text)
        except SarvamError as e:
            notes.append(f"Vision digitise unavailable ({e.status or 'error'}).")

    # --- 3. Local fallback --------------------------------------------
    if not parsed and stored_path and source_type == "pdf":
        txt = local_pdf_text(stored_path)
        if txt:
            parsed = parse_digitised(txt)
            digitised_text = digitised_text or txt
            method.append("local_pdf_text")
            notes.append("Used local PDF text layer (no OCR) — scanned reports need Sarvam Vision.")

    # --- merge ---------------------------------------------------------
    parse_values = parsed.get("values", {}) if parsed else {}
    values: dict[str, float] = {}
    provenance: dict[str, str] = {}
    disagreements: list[dict] = []

    for p in PARAMS:
        if p in vision_values:
            values[p] = vision_values[p]
            provenance[p] = "sarvam_vision_extract"
        elif p in parse_values:
            values[p] = parse_values[p]
            provenance[p] = "ocr_text_parse"
        if p in vision_values and p in parse_values:
            a, b = vision_values[p], parse_values[p]
            if abs(a - b) > max(0.05, 0.02 * abs(a)):
                disagreements.append({
                    "param": p, "level": "disagreement",
                    "message": f"Vision read {a}, OCR text read {b}. Please confirm against the report.",
                })

    metadata = dict(parsed.get("metadata", {})) if parsed else {}
    units = dict(parsed.get("units", {})) if parsed else {}
    for p in PARAMS:
        if p in values and p not in units:
            units[p] = PARAM_META[p]["unit"]

    extraction = {
        "filename": filename,
        "source_type": source_type,
        "methods": method,
        "values": values,
        "units": units,
        "metadata": metadata,
        "confidence": {k: (v if isinstance(v, dict) else {"confidence": v})
                       for k, v in confidence.items() if k in PARAMS},
        "provenance": provenance,
        "printed_recommendation": (parsed.get("printed_recommendation", "") if parsed else ""),
        "is_synthetic": _is_synthetic(digitised_text, filename),
        "notes": notes,
        "digitised_excerpt": (digitised_text or "")[:1500],
    }

    # --- validation ----------------------------------------------------
    validated = validate_extraction(extraction)
    validated["flags"].extend(disagreements)
    extraction["validation"] = validated
    return extraction
