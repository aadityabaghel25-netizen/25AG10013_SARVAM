"""Deterministic parser for digitised soil-report text.

This never guesses: it only reads what is literally present in the OCR output
(markdown/HTML tables or `label: value` lines). Used to (a) cross-check the
schema-based Vision extraction and (b) recover units and the "as printed"
fertiliser recommendation, which the numeric schema does not capture.
"""
from __future__ import annotations

import re

from .schema import PARAMS

# name keyword -> canonical param. Ordered so longer/more specific keys win.
KEYWORDS: list[tuple[str, str]] = [
    ("electrical conductivity", "ec"),
    ("organic carbon", "organic_carbon"),
    ("available nitrogen", "nitrogen"),
    ("available phosphorus", "phosphorus"),
    ("available potassium", "potassium"),
    ("available phosphorous", "phosphorus"),
    ("nitrogen", "nitrogen"),
    ("phosphorus", "phosphorus"),
    ("phosphorous", "phosphorus"),
    ("potassium", "potassium"),
    ("sulphur", "sulphur"),
    ("sulfur", "sulphur"),
    ("manganese", "manganese"),
    ("molybdenum", None),  # ignore but keep order
    ("copper", "copper"),
    ("boron", "boron"),
    ("zinc", "zinc"),
    ("iron", "iron"),
    ("p2o5", "phosphorus"),
    ("k2o", "potassium"),
    ("ec", "ec"),
    ("ph", "ph"),
]

_NUM = re.compile(r"-?\d+(?:\.\d+)?")
_UNIT = re.compile(r"(kg\s*/\s*ha|kg\s*/\s*acre|dS\s*/\s*m|mg\s*/\s*kg|ppm|%|cmol)", re.I)
_LABEL = re.compile(r"([A-Za-z][A-Za-z /().\-]{1,40}?)\s*:\s*([^\n<|]+)")
# Ordered most-specific-first so "Sample Collection Date" wins over "Sample".
_META_KEYS = [
    ("collection date", "collection_date"), ("report date", "report_date"),
    ("farmer", "farmer_name"), ("laborator", "laboratory"),
    ("district", "district"), ("plot", "plot"), ("survey", "plot"),
    ("crop", "crop"), ("sample", "sample_id"), ("card id", "sample_id"),
    ("sample id", "sample_id"),
]


def _meta_key(label: str) -> str | None:
    low = label.lower()
    for needle, key in _META_KEYS:
        if needle in low:
            return key
    return None


def _param_for(label: str) -> str | None:
    low = label.lower()
    # Skip the EC/OC substring collisions: check "ph" only as a token.
    for key, param in KEYWORDS:
        if param is None:
            continue
        if key in ("ph", "ec") and key in low:
            if re.search(rf"\b{key}\b", low):
                return param
        elif key in low:
            return param
    return None


def _first_number(text: str) -> float | None:
    m = _NUM.search(text or "")
    return float(m.group()) if m else None


def parse_digitised(text: str) -> dict:
    """Return {values, units, metadata, printed_recommendation, lines_seen}."""
    values: dict[str, float] = {}
    units: dict[str, str] = {}
    metadata: dict[str, str] = {}
    printed = ""

    # 1) HTML table rows ------------------------------------------------
    for row in re.findall(r"<tr>(.*?)</tr>", text, flags=re.I | re.S):
        cells = re.findall(r"<td>(.*?)</td>", row, flags=re.I | re.S)
        cells = [re.sub(r"<[^>]+>", "", c).strip() for c in cells]
        if len(cells) < 2:
            continue
        param = _param_for(cells[0])
        if not param:
            continue
        val = _first_number(cells[1])
        if val is not None and param not in values:
            values[param] = val
            if len(cells) >= 3:
                um = _UNIT.search(cells[2])
                if um:
                    units[param] = um.group(1)

    # 2) `label: value` or `label ... value` lines ----------------------
    for line in text.splitlines():
        plain = re.sub(r"<[^>]+>", " ", line).strip()
        if not plain:
            continue
        low = plain.lower()
        if "fertil" in low or "recommend" in low or "dose" in low:
            printed = (printed + " " + plain).strip()
        param = _param_for(plain)
        if param and param not in values:
            val = _first_number(plain)
            if val is not None:
                values[param] = val
                um = _UNIT.search(plain)
                if um:
                    units[param] = um.group(1)

    # Printed fertiliser lines: collect bullet lines following the header.
    if printed:
        block = []
        capture = False
        for line in text.splitlines():
            plain = re.sub(r"<[^>]+>", " ", line).strip()
            if not plain:
                continue
            low = plain.lower()
            if "fertil" in low or "recommend" in low or "dose" in low:
                capture = True
                continue
            if capture and (plain.startswith("-") or plain.startswith("*") or "kg" in low):
                block.append(plain.lstrip("-* ").strip())
        if block:
            printed = " | ".join(block[:8])

    # 3) metadata: scan every ':' and look back for a label -----------------
    plain_all = re.sub(r"<[^>]+>", " ", text)
    for m in re.finditer(r":", plain_all):
        i = m.start()
        pre = plain_all[max(0, i - 45):i]
        lm = re.search(r"([A-Za-z][A-Za-z /().\-]{1,40})$", pre)
        if not lm:
            continue
        key = _meta_key(lm.group(1).strip())
        if not key or key in metadata:
            continue
        nxt = plain_all.find(":", i + 1)
        end = nxt if nxt != -1 else len(plain_all)
        val = plain_all[i + 1:end].split("\n")[0].split("|")[0].strip()
        if not val:
            # Sarvam OCR often emits `label:` then a blank line then the value.
            for ln in plain_all[i + 1:].split("\n"):
                s = ln.strip()
                if not s:
                    continue
                if _meta_key(s) and len(s) < 30:
                    break  # hit the next label; no value for this one
                val = s.split("|")[0].strip()
                break
        if val and not re.fullmatch(r"[\d\s./-]+", val):
            metadata[key] = val

    return {"values": values, "units": units, "metadata": metadata,
            "printed_recommendation": printed, "text_chars": len(text)}


def local_pdf_text(path: str) -> str:
    """Offline fallback: extract embedded text from a text-based PDF.

    Scanned/handwritten reports need Sarvam Vision; this only works for PDFs
    that already contain a text layer.
    """
    try:
        import pdfplumber
    except ImportError:
        return ""
    out = []
    try:
        with pdfplumber.open(path) as pdf:
            for page in pdf.pages[:10]:
                out.append(page.extract_text() or "")
    except Exception:
        return ""
    return "\n".join(out)
