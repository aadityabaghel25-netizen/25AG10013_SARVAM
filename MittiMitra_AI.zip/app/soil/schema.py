"""Canonical soil parameter definitions, units, and the extraction schema.

The schema drives Sarvam Vision's schema-based `extract` call so we get
structured values plus per-field confidence and page provenance.
"""
from __future__ import annotations

# Canonical parameter keys used everywhere in the app.
PARAMS = ["ph", "ec", "organic_carbon", "nitrogen", "phosphorus", "potassium",
          "sulphur", "zinc", "iron", "copper", "manganese", "boron"]

# Human + Hindi labels and expected units.
PARAM_META: dict[str, dict] = {
    "ph": {"en": "pH", "hi": "पी.एच. (pH)", "unit": "", "kind": "index"},
    "ec": {"en": "Electrical Conductivity (EC)", "hi": "विद्युत चालकता (EC)", "unit": "dS/m", "kind": "index"},
    "organic_carbon": {"en": "Organic Carbon (OC)", "hi": "जैविक कार्बन (OC)", "unit": "%", "kind": "nutrient"},
    "nitrogen": {"en": "Available Nitrogen (N)", "hi": "उपलब्ध नाइट्रोजन (N)", "unit": "kg/ha", "kind": "nutrient"},
    "phosphorus": {"en": "Available Phosphorus (P)", "hi": "उपलब्ध फॉस्फोरस (P)", "unit": "kg/ha", "kind": "nutrient"},
    "potassium": {"en": "Available Potassium (K)", "hi": "उपलब्ध पोटैशियम (K)", "unit": "kg/ha", "kind": "nutrient"},
    "sulphur": {"en": "Sulphur (S)", "hi": "सल्फर (S)", "unit": "mg/kg", "kind": "nutrient"},
    "zinc": {"en": "Zinc (Zn)", "hi": "जिंक (Zn)", "unit": "mg/kg", "kind": "micronutrient"},
    "iron": {"en": "Iron (Fe)", "hi": "आयरन (Fe)", "unit": "mg/kg", "kind": "micronutrient"},
    "copper": {"en": "Copper (Cu)", "hi": "कॉपर (Cu)", "unit": "mg/kg", "kind": "micronutrient"},
    "manganese": {"en": "Manganese (Mn)", "hi": "मैंगनीज़ (Mn)", "unit": "mg/kg", "kind": "micronutrient"},
    "boron": {"en": "Boron (B)", "hi": "बोरॉन (B)", "unit": "mg/kg", "kind": "micronutrient"},
}

# Absolute plausibility bounds. A value outside these is physically implausible
# for a soil test and must be flagged, never used.
PLAUSIBLE = {
    "ph": (2.0, 11.0),
    "ec": (0.0, 30.0),
    "organic_carbon": (0.0, 5.0),
    "nitrogen": (0.0, 1200.0),
    "phosphorus": (0.0, 300.0),
    "potassium": (0.0, 1200.0),
    "sulphur": (0.0, 300.0),
    "zinc": (0.0, 100.0),
    "iron": (0.0, 500.0),
    "copper": (0.0, 100.0),
    "manganese": (0.0, 500.0),
    "boron": (0.0, 50.0),
}

# Fields we ask Sarvam Vision to extract (metadata + the six core parameters).
EXTRACTION_SCHEMA: dict = {
    "type": "object",
    "properties": {
        "farmer_name": {"type": "string", "description": "Name of the farmer on the report"},
        "sample_id": {"type": "string", "description": "Sample / card / lab reference number"},
        "laboratory": {"type": "string", "description": "Testing laboratory name"},
        "district": {"type": "string", "description": "District and state of the sample"},
        "plot": {"type": "string", "description": "Plot / survey / khasra number"},
        "collection_date": {"type": "string", "description": "Date the soil sample was collected"},
        "report_date": {"type": "string", "description": "Date the report was issued"},
        "crop": {"type": "string", "description": "Crop named on the report, if any"},
        "ph": {"type": "number", "description": "Soil pH value"},
        "ec": {"type": "number", "description": "Electrical conductivity in dS/m"},
        "organic_carbon": {"type": "number", "description": "Organic carbon in percent"},
        "nitrogen": {"type": "number", "description": "Available nitrogen in kg/ha"},
        "phosphorus": {"type": "number", "description": "Available phosphorus in kg/ha"},
        "potassium": {"type": "number", "description": "Available potassium in kg/ha"},
        "sulphur": {"type": "number", "description": "Sulphur in mg/kg"},
        "zinc": {"type": "number", "description": "Zinc in mg/kg"},
        "iron": {"type": "number", "description": "Iron in mg/kg"},
        "copper": {"type": "number", "description": "Copper in mg/kg"},
        "manganese": {"type": "number", "description": "Manganese in mg/kg"},
        "boron": {"type": "number", "description": "Boron in mg/kg"},
        "printed_fertiliser_recommendation": {
            "type": "string",
            "description": "Any fertiliser dose printed on the report, verbatim, or empty",
        },
    },
}
