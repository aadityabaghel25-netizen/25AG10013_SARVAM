"""Central configuration for MittiMitra AI.

All secrets are read from the environment. Never hardcode an API key here.
Copy `.env.example` to `.env` and put your key in it.
"""
from __future__ import annotations

import os
from pathlib import Path


def _load_dotenv() -> None:
    """Minimal .env loader (no external dependency)."""
    for candidate in (Path.cwd() / ".env", Path(__file__).resolve().parent.parent / ".env"):
        if candidate.exists():
            for line in candidate.read_text().splitlines():
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, _, val = line.partition("=")
                key, val = key.strip(), val.strip().strip('"').strip("'")
                os.environ.setdefault(key, val)


_load_dotenv()

# --- Sarvam API -----------------------------------------------------------
SARVAM_API_KEY = os.environ.get("SARVAM_API_KEY", "")
SARVAM_BASE_URL = os.environ.get("SARVAM_BASE_URL", "https://api.sarvam.ai")

# Model identifiers verified against https://docs.sarvam.ai (Oct 2026)
CHAT_MODEL = os.environ.get("SARVAM_CHAT_MODEL", "sarvam-105b")
STT_MODEL = os.environ.get("SARVAM_STT_MODEL", "saaras:v4")
TTS_MODEL = os.environ.get("SARVAM_TTS_MODEL", "bulbul:v3")
TTS_SPEAKER = os.environ.get("SARVAM_TTS_SPEAKER", "shubh")
TRANSLATE_MODEL = os.environ.get("SARVAM_TRANSLATE_MODEL", "mayura:v1")

# When true, Sarvam calls are skipped and the app uses clearly-labelled local
# fallbacks. Set OFFLINE=1 for a no-network demo.
OFFLINE = os.environ.get("MITTIMITRA_OFFLINE", "0") == "1"

# --- Storage --------------------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = os.environ.get("MITTIMITRA_DB", str(BASE_DIR / "data" / "mittimitra.db"))
UPLOAD_DIR = Path(os.environ.get("MITTIMITRA_UPLOADS", str(BASE_DIR / "data" / "uploads")))
KB_PATH = Path(os.environ.get("MITTIMITRA_KB", str(BASE_DIR / "app" / "kb" / "data" / "knowledge_base.json")))

UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

# Languages offered in the UI (verified as supported by Sarvam translate/TTS;
# see docs/ARCHITECTURE.md for the support matrix).
LANGUAGES = {
    "hi-IN": {"name": "Hindi", "native": "हिन्दी"},
    "bn-IN": {"name": "Bengali", "native": "বাংলা"},
    "mr-IN": {"name": "Marathi", "native": "मराठी"},
    "gu-IN": {"name": "Gujarati", "native": "ગુજરાતી"},
    "ta-IN": {"name": "Tamil", "native": "தமிழ்"},
    "te-IN": {"name": "Telugu", "native": "తెలుగు"},
    "kn-IN": {"name": "Kannada", "native": "ಕನ್ನಡ"},
    "ml-IN": {"name": "Malayalam", "native": "മലയാളം"},
    "pa-IN": {"name": "Punjabi", "native": "ਪੰਜਾਬੀ"},
    "od-IN": {"name": "Odia", "native": "ଓଡ଼ିଆ"},
    "as-IN": {"name": "Assamese", "native": "অসমীয়া"},
    "en-IN": {"name": "English", "native": "English"},
}
