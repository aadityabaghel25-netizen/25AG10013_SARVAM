# Demo Script — MittiMitra AI (≈4 minutes)

**One-line pitch:** *MittiMitra AI reads a farmer's soil test report and explains it in their own
language, out loud — while refusing to guess any number it cannot see.*

---

### 0:00 — The problem (20s)
"Over 12 crore Soil Health Cards have been issued in India, but most farmers can't read them. The
card lists pH, EC, nitrogen, phosphorus, potassium — as numbers and ranges. A farmer with low
literacy, or no smartphone, is left guessing, and often over-applies urea. Meanwhile the advice
that could help is locked in PDFs and extension bulletins."

### 0:20 — The solution, in one breath (15s)
"MittiMitra takes a soil report — a PDF or even a photo — reads the values with **Sarvam Vision**,
checks them with hard rules, and explains them in simple language, spoken aloud in the farmer's
own language. An agricultural agent can run it too, and print a paper report for farmers without a
phone."

### 0:35 — Live demo, part 1: report → values (50s)
1. Open the app. Enter farmer "Ramesh Kumar". Upload `sample_report_en.pdf`
   (a **watermarked SYNTHETIC** report, so nothing here is mistaken for a real test).
2. Point out the extracted table: **pH 5.6, EC 0.21, OC 0.38%, N 198, P 14, K 92 kg/ha, S 8.4, Zn 0.42** —
   with units, and each value tagged with its source (`sarvam_vision_extract` / `ocr_text_parse`).
3. Show the **Uncertain / missing** panel: zinc confidence, and the four micronutrients that simply
   aren't on this report — "the app tells you what it *couldn't* read instead of inventing it."

### 1:25 — Live demo, part 2: values → advice (60s)
4. Enter crop **Paddy**, location **Nadia, West Bengal**, language **हिन्दी**.
5. Press *Generate explanation*. Show the Hindi explanation: it says organic carbon, nitrogen,
   potassium, sulphur and zinc are low; pH 5.6 is *suitable for paddy*; each point names why it
   matters and what the official guidance suggests.
6. Scroll to **Sources** — ICAR-IISS, Soil Health Card Scheme, TNAU Agritech, FAO — and
   **Limitations**, which state plainly this is not a fertiliser prescription.
7. Press **🔊 Play audio** — the Hindi voice (Bulbul) reads the summary.
8. Press **🖨️ Printable report** — a clean one-page sheet an agent can hand over.

### 2:25 — Live demo, part 3: voice (30s)
9. Go to *Ask by voice*. Record (or type) *"मेरी मिट्टी में नाइट्रोजन कम है, क्या करूँ?"*
   It is transcribed by **Saaras** and answered from the report + knowledge base, in Hindi.

### 2:55 — Technical innovation (40s)
"What makes this trustworthy is the **separation of powers**:
- the **LLM never sees a blank field** — it is handed a frozen block of numbers and told it may not
  invent any;
- every low/suitable/high label comes from **deterministic rules**, not the model;
- extraction is **doubled** — schema extraction *and* full OCR text parsing — and any disagreement
  is surfaced as a flag;
- it runs across **12 Indian languages** by generating once and translating, so numbers and chemical
  names survive intact."

### 3:35 — Scalability & impact (25s)
"Stateless FastAPI + SQLite today, PostgreSQL and queues tomorrow. The same `/api/advisory` and
`/api/voice` endpoints power a web app, a WhatsApp bot, or an IVR for feature phones — reaching the
farmers who need it most. And because every recommendation carries a source and a confidence, the
system is auditable enough for a government or KVK deployment."

---

### Backup talking points (if asked)
- **Why Sarvam?** Vision handles scanned/handwritten Indic reports; Saaras and Bulbul make it
  voice-first in 11+ Indian languages; 105B writes natural, culturally appropriate Hindi.
- **What's simulated?** Only the sample *report* — clearly watermarked. All model calls are real.
- **What would you do with more time?** Region-specific reference ranges, more KB entries per crop,
  WhatsApp/IVR channels, and a feedback loop where KVKs correct recommendations.
