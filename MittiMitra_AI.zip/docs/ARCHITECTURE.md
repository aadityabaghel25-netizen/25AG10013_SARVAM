# Architecture — MittiMitra AI

## 1. High-level flow

```
                         ┌─────────────────────────────────────────────────────────────┐
                         │  Farmer (mobile browser / IVR-style voice)  ·  Agent dashboard │
                         └───────────────┬─────────────────────────────────────────────┘
                                         │  upload PDF/image · record voice · pick language
                                         ▼
┌────────────────────────────────────────────────────────────────────────────────────────────┐
│                                   FastAPI backend (app/main.py)                              │
│                                                                                              │
│   POST /api/samples/upload        POST /api/advisory        POST /api/voice/stt & /tts       │
│   POST /api/farmers               POST /api/ask             GET  /api/report/{id}/print       │
└───────┬───────────────────────────────────┬───────────────────────────────┬─────────────────┘
        │                                   │                               │
        ▼                                   ▼                               ▼
┌───────────────────┐   ┌───────────────────────────────┐   ┌───────────────────────────────┐
│ 1. DOCUMENT        │   │ 2. AGRICULTURAL CALCULATION   │   │ 4. LANGUAGE GENERATION        │
│    EXTRACTION      │   │    (deterministic, no LLM)    │   │    (Sarvam)                   │
│                    │   │                               │   │                               │
│ Sarvam Vision      │   │ validators.py                 │   │ explainer.py                  │
│  • extract(schema) │   │  • reference bands            │   │  • Sarvam-105B grounded       │
│    → values +      │──▶│  • plausibility bounds        │──▶│    prompt (numbers locked)    │
│    confidence +    │   │  • crop pH windows            │   │  • Sarvam Translate → 22 langs│
│    page sources    │   │ interpreter.py                │   │  • follow-up Q&A              │
│  • digitise → OCR  │   │  • low / suitable / high      │   │ Sarvam TTS (Bulbul) → audio   │
│    text (units,    │   │  • attach KB guidance         │   │ Sarvam STT (Saaras) ← voice   │
│    metadata, doses)│   └───────────────┬───────────────┘   └───────────────────────────────┘
│  • local pdfplumber│                   │
│    fallback        │                   ▼
└───────────────────┘   ┌───────────────────────────────┐
                        │ 3. KNOWLEDGE RETRIEVAL        │
                        │    kb.py + knowledge_base.json│
                        │  ICAR · KVK · Soil Health Card│
                        │  TNAU · FAO  (source-tagged)  │
                        └───────────────────────────────┘

                    Persistence: SQLite (db.py) — farmers · samples · advisories · sample_status
```

The four layers are deliberately separate modules with no hidden coupling, so each can be tested,
replaced or scaled independently.

## 2. Why this split keeps the LLM honest

```
report ──► extract (Vision) ──► validate (rules) ──► interpret (rules) ──► phrase (LLM) ──► translate
             │                      │                    │                     │
        the only source        rejects impossible    decides low/high      may ONLY use
        of numbers             /missing values       + picks KB snippet    the numbers given
```

- **Numbers** come only from extraction.
- **Categories** (low / suitable / high) come only from `validators.py`.
- **Actions** come only from the curated KB.
- The LLM receives a frozen facts block and a system prompt forbidding invented measurements/doses.

## 3. Extraction strategy (defence in depth)

| Step | Source | What it gives |
|---|---|---|
| 1 | Sarvam Vision `extract` (JSON schema) | typed values + per-field confidence + page provenance |
| 2 | Sarvam Vision `digitise` (markdown) → deterministic parser | units, sample metadata, the "as printed" fertiliser dose, an independent value set |
| 3 | `pdfplumber` local text | offline fallback for text-layer PDFs only |

Values from (1) and (2) are **cross-checked**; any disagreement becomes a `disagreement` flag.
Missing values are reported, never filled in.

## 4. API verification log (live, during build)

| Capability | Call | Result |
|---|---|---|
| Chat | `POST /v1/chat/completions` `sarvam-105b` | ✅ returns text (reasoning model — needs generous `max_tokens`) |
| Translate | `POST /translate` `mayura:v1` en→hi | ✅ `"मिट्टी का पी. एच. कम है।"` |
| TTS | `POST /text-to-speech` `bulbul:v3` & `bulbul:v4-flash` | ✅ base64 WAV returned |
| Document AI — digitise | `POST /doc-ai/v1/job/digitise` | ✅ markdown with an HTML table |
| Document AI — extract | `POST /doc-ai/v1/job/extract` + `.../results` | ✅ JSON values + confidence + page sources |
| Speech-to-text | `POST /speech-to-text` `saaras:v4` | ✅ round-trip of our own TTS audio transcribed correctly |

Auth header used throughout: `api-subscription-key`.

## 5. Language support matrix

| Language | Code | Translate (Mayura) | TTS (Bulbul) | Chat (Sarvam-105B) |
|---|---|:--:|:--:|:--:|
| Hindi | `hi-IN` | ✅ | ✅ | ✅ |
| Bengali | `bn-IN` | ✅ | ✅ | ✅ |
| Marathi | `mr-IN` | ✅ | ✅ | ✅ |
| Gujarati | `gu-IN` | ✅ | ✅ | ✅ |
| Tamil | `ta-IN` | ✅ | ✅ | ✅ |
| Telugu | `te-IN` | ✅ | ✅ | ✅ |
| Kannada | `kn-IN` | ✅ | ✅ | ✅ |
| Malayalam | `ml-IN` | ✅ | ✅ | ✅ |
| Punjabi | `pa-IN` | ✅ | ✅ | ✅ |
| Odia | `od-IN` | ✅ | ✅ | ✅ |
| Assamese | `as-IN` | ✅ (Sarvam-Translate) | — | — |
| English | `en-IN` | ✅ | ✅ | ✅ |

The explanation is generated in English and then translated, so **numbers, units and chemical
names survive translation intact** and any language can be added by extending the `LANGUAGES` map
in `config.py`. Assamese (and 10 further scheduled languages) can be served via
`sarvam-translate:v1`; switching is a one-line config change.

## 6. Data model (SQLite)

```
farmers(id, name, phone, village, district, state, created_at)
samples(id, farmer_id, filename, stored_path, source_type, is_synthetic, extraction_json, created_at)
advisories(id, sample_id, language, advisory_json, created_at)
sample_status(id, sample_id, status, note, at)      -- lab lifecycle log
```

## 7. Scaling notes

- Stateless API → run many replicas behind a load balancer; move SQLite to PostgreSQL.
- Document AI and chat calls are the latency cost; they can be queued (Celery/RQ) so the UI
  streams status, as the agent dashboard already does for lab status.
- Add caching keyed on report hash to avoid re-OCR of the same document.
- An IVR/WhatsApp front end can reuse the same `/api/advisory` + `/api/voice/*` endpoints.
