# Setup & Running — MittiMitra AI

## 1. Requirements

- Python 3.10+ (tested on 3.12)
- A Sarvam AI API key — create one at <https://dashboard.sarvam.ai>
- Internet access (for the Sarvam APIs). Optional: a modern browser with microphone for voice.

## 2. Install

```bash
git clone <your-repo>        # or unzip the submission
cd mittimitra
python -m venv .venv && source .venv/bin/activate    # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## 3. Configure

```bash
cp .env.example .env
```

Edit `.env` and set your key:

```
SARVAM_API_KEY=your_key_here
```

> **Never commit `.env`.** It is already in `.gitignore`. The app reads the key only from the
> environment; no key is hard-coded anywhere in the source.

Optional settings in `.env`:

| Variable | Default | Meaning |
|---|---|---|
| `MITTIMITRA_OFFLINE` | `0` | set `1` for a no-network demo with labelled fallbacks |
| `SARVAM_CHAT_MODEL` | `sarvam-105b` | explanation model |
| `SARVAM_TTS_SPEAKER` | `shubh` | Bulbul voice |
| `MITTIMITRA_DB` | `./data/mittimitra.db` | SQLite path |

## 4. Run

```bash
uvicorn app.main:app --reload --port 8000
```

Open <http://localhost:8000>. On a phone on the same network, use
`http://<your-machine-ip>:8000` (the UI is mobile-first).

## 5. Verify everything works

```bash
# deterministic rule/parser tests (no network needed)
python tests/test_validators.py        # → "7 tests passed."

# generate the synthetic sample report
python scripts/make_synthetic_report.py --out data/samples/sample_report_en.pdf

# full end-to-end run against the LIVE Sarvam APIs
python scripts/smoke_test.py
```

`smoke_test.py` writes artifacts to `data/artifacts/`:
`extraction.json`, `advisory_hi.json`, `spoken_hi.wav`, `printable_report_hi.html`.

## 6. Using the app

1. **Upload & Extract** — enter the farmer's details, choose a soil report (PDF or photo), press
   *Extract report*. You'll see the extracted values, their provenance, and any uncertain/missing
   flags.
2. **Advice** — enter the crop and location, pick a language, press *Generate explanation*. You get
   a plain-language explanation, a parameter status table, sources, limitations, an audio button
   and a *Printable report* button.
3. **Ask by voice** — record a question (or type it) and get a grounded answer you can play aloud.
4. **Agent dashboard** — record laboratory sample status and view recent samples.

## 7. Troubleshooting

| Symptom | Fix |
|---|---|
| Banner says "Sarvam OFFLINE" | `.env` missing/invalid key, or `MITTIMITRA_OFFLINE=1` |
| `403` from Sarvam | key invalid or out of credits |
| Explanation is English though a language was chosen | translation step failed — see the note under the explanation; check credits |
| Scanned report extracts nothing | ensure it is a PDF/PNG/JPEG ≤10 pages; Document AI handles scans/handwriting |
| Microphone button does nothing | browser must serve over `localhost` or HTTPS and you must grant mic permission |
| Chat returns empty text | `sarvam-105b` is a reasoning model; the app already raises `max_tokens`, but a very low credit balance can truncate it |

## 8. Deploying (optional)

```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 4
```

Put a reverse proxy (nginx/Caddy) in front for TLS, and swap SQLite for PostgreSQL by pointing
`MITTIMITRA_DB` at a managed instance (a thin DB adapter is the only change needed).
