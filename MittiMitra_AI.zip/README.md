# 🌱 MittiMitra AI

**Voice-first soil report and agricultural advisory assistant for Indian farmers.**

Many farmers cannot read a soil-test report, lack reliable advice, or don't own a smartphone.
MittiMitra AI takes a soil report (PDF or photo), reads the values out with **Sarvam Vision**,
interprets them against official reference ranges, and explains the result in simple language —
spoken aloud in the farmer's own language. Agricultural agents can also run it from a dashboard
and print a paper report for farmers without phones.

> Built for the Sarvam AI Hackathon. Core workflow first (report → explanation), then voice and
> the agent dashboard — exactly as the brief prioritised.

---

## What works right now (verified live)

Every capability below was run against the live Sarvam API during development (see
`docs/ARCHITECTURE.md` for the verification log and `docs/LIMITATIONS.md` for honest status):

| Feature | Status | How |
|---|---|---|
| Upload soil report (PDF **or** image) | ✅ working | `POST /api/samples/upload` |
| Extract pH, EC, OC, N, P, K, S, Zn + units + sample metadata | ✅ working | Sarvam Vision `extract` **+** `digitise` |
| Show values with the source document & flag uncertain extraction | ✅ working | per-field confidence + plausibility + cross-check |
| Ask for crop / location | ✅ working | UI form |
| Knowledge base from ICAR / KVK / Soil Health Card / TNAU / FAO | ✅ working | 20 curated, source-tagged entries |
| Explicit validation rules + crop-specific guidance | ✅ working | deterministic `validators.py` |
| Simple explanation in Hindi (+ 11 languages) with sources & limitations | ✅ working | Sarvam-105B grounded → Sarvam Translate |
| Spoken questions & audio answers | ✅ working | Saaras `saaras:v4` (STT), Bulbul `bulbul:v3` (TTS) |
| Agent dashboard (farmer details, upload, lab status) | ✅ working | `/api/farmers`, `/api/samples/.../status` |
| Mobile-friendly UI + printable report | ✅ working | responsive UI, `/api/report/{id}/print` |

**Safety guarantee:** the language model is never allowed to invent a soil measurement or a
fertiliser/pesticide dose. All numbers come from the extracted report; all categories come from
deterministic rules; all actions come from the curated knowledge base. The LLM only *phrases*.

---

## Quickstart

```bash
# 1. Install
pip install -r requirements.txt

# 2. Add your Sarvam API key
cp .env.example .env
#   then edit .env and set SARVAM_API_KEY=...   (get one at https://dashboard.sarvam.ai)

# 3. Run
uvicorn app.main:app --reload --port 8000
#   open http://localhost:8000
```

No API key? Set `MITTIMITRA_OFFLINE=1` in `.env` to run the whole UI with clearly-labelled local
fallbacks (text-PDF parsing + template explanations, no OCR/voice/translation).

Full instructions, tests and the demo walkthrough: [`docs/SETUP.md`](docs/SETUP.md).

---

## Project layout

```
mittimitra/
├── app/
│   ├── main.py              FastAPI routes + printable report
│   ├── config.py            env/config (models, languages, paths)
│   ├── sarvam.py            Sarvam API client (chat, STT, TTS, translate, Doc AI)
│   ├── db.py                SQLite: farmers, samples, advisories, lab status
│   ├── soil/
│   │   ├── schema.py        parameter metadata + Vision extraction schema
│   │   ├── parse.py         deterministic OCR-text parser (cross-check + units)
│   │   ├── validators.py    reference ranges, plausibility, flagging  ← the rules
│   │   └── extract.py       orchestrates extract + digitise + validate
│   ├── kb/
│   │   ├── kb.py            transparent keyword retrieval
│   │   └── data/knowledge_base.json   ← curated KB with source metadata
│   ├── advisory/
│   │   ├── interpreter.py   value → low/suitable/high + KB guidance
│   │   ├── explainer.py     grounded LLM explanation + translation + follow-ups
│   │   └── report.py        assembles the final advisory object
│   └── static/index.html    mobile-friendly single-page UI
├── scripts/
│   ├── make_synthetic_report.py   generates the watermarked sample report
│   └── smoke_test.py              end-to-end test against live Sarvam APIs
├── tests/test_validators.py       7 deterministic unit tests
└── docs/  ARCHITECTURE.md · SETUP.md · DEMO_SCRIPT.md · LIMITATIONS.md
```

Modular by design: **document extraction**, **agricultural calculations**, **knowledge
retrieval** and **language generation** are four separate, independently testable layers.

---

## Sarvam models used

| Purpose | Endpoint | Model |
|---|---|---|
| Document extraction | `POST /doc-ai/v1/job/extract`, `.../digitise` | Sarvam Vision 1.5 |
| Speech recognition | `POST /speech-to-text` | `saaras:v4` |
| Speech synthesis | `POST /text-to-speech` | `bulbul:v3` |
| Explanation / conversation | `POST /v1/chat/completions` | `sarvam-105b` |
| Translation | `POST /translate` | `mayura:v1` |

---

## Deliverables in this repo

- **Working end-to-end demo** — `scripts/smoke_test.py` runs the whole flow; artifacts in `data/artifacts/`.
- **Source code & setup** — this repo + `docs/SETUP.md`.
- **Architecture diagram** — `docs/ARCHITECTURE.md`.
- **Sample knowledge base with source metadata** — `app/kb/data/knowledge_base.json`.
- **Example soil-report workflow** — `docs/DEMO_SCRIPT.md` + the sample report.
- **Hindi voice demonstration** — `data/artifacts/spoken_hi.wav` (generated by the smoke test).
- **Demo script** — `docs/DEMO_SCRIPT.md`.
- **Limitations, test results & next steps** — `docs/LIMITATIONS.md`.

---

## Safety, honesty and scope

- Synthetic test reports are **watermarked "SYNTHETIC"** and flagged in the UI and API.
- Where a value is missing, unreadable, implausible or low-confidence, it is **excluded and
  listed as uncertain** — never guessed.
- The assistant **does not prescribe** fertiliser or pesticide doses; it points to the farmer's
  Soil Health Card / KVK / State Agriculture Department.
- These are indicative general reference bands, not a substitute for a soil-test-based
  recommendation.
