"""End-to-end smoke test using FastAPI's in-process TestClient.

Exercises the whole workflow against the live Sarvam APIs:
  upload -> extract -> validate -> interpret -> explain (Hindi) -> TTS -> STT -> ask -> print

Writes artifacts to data/artifacts/ for inspection.
Run:  python scripts/smoke_test.py
"""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from fastapi.testclient import TestClient  # noqa: E402

from app.main import app  # noqa: E402
from app import db as _db  # noqa: E402

_db.init_db()

ART = ROOT / "data" / "artifacts"
ART.mkdir(parents=True, exist_ok=True)
PDF = ROOT / "data" / "samples" / "sample_report_en.pdf"


def step(msg):
    print(f"\n=== {msg} ===")


def main():
    if not PDF.exists():
        from scripts.make_synthetic_report import build
        build(str(PDF))

    c = TestClient(app)

    step("health")
    h = c.get("/api/health").json()
    print(json.dumps(h, indent=1))

    step("create farmer")
    fid = c.post("/api/farmers", json={"name": "Ramesh Kumar", "village": "Chapra",
                                       "district": "Nadia", "state": "West Bengal"}).json()["farmer_id"]
    print("farmer_id:", fid)

    step("upload + extract")
    t0 = time.time()
    with open(PDF, "rb") as f:
        r = c.post("/api/samples/upload",
                   files={"file": ("sample_report_en.pdf", f, "application/pdf")},
                   data={"farmer_id": fid, "language": "en-IN"})
    up = r.json()
    sid = up["sample_id"]
    ex = up["extraction"]
    print(f"sample_id: {sid}  ({time.time()-t0:.1f}s)")
    print("methods:", ex["methods"])
    print("values:", json.dumps(ex["values"], indent=1))
    print("units:", ex["units"])
    print("metadata:", ex["metadata"])
    print("is_synthetic:", ex["is_synthetic"])
    print("flags:", [f["message"] for f in ex["validation"]["flags"]])
    (ART / "extraction.json").write_text(json.dumps(ex, indent=1, ensure_ascii=False))

    step("advisory (Hindi)")
    t0 = time.time()
    adv = c.post("/api/advisory", json={"sample_id": sid, "crop": "Paddy",
                                        "location": "Nadia, West Bengal",
                                        "language": "hi-IN", "use_llm": True}).json()
    print(f"({time.time()-t0:.1f}s) translated={adv.get('translated')}")
    print("summary:", json.dumps(adv["summary"], ensure_ascii=False))
    print("--- explanation (first 600 chars) ---")
    print(adv["explanation"][:600])
    print("--- sources ---")
    for s in adv["sources"]:
        print(" -", s["title"], "|", s["org"])
    (ART / "advisory_hi.json").write_text(json.dumps(adv, indent=1, ensure_ascii=False))

    step("TTS (Hindi spoken summary)")
    tts = c.post("/api/voice/tts", json={"text": adv["spoken_summary"], "language": "hi-IN"})
    if tts.status_code == 200 and tts.content:
        (ART / "spoken_hi.wav").write_bytes(tts.content)
        print(f"audio bytes: {len(tts.content)} -> data/artifacts/spoken_hi.wav")
    else:
        print("TTS failed:", tts.status_code, tts.text[:200])

    step("STT round-trip (feed the TTS audio back)")
    if (ART / "spoken_hi.wav").exists():
        with open(ART / "spoken_hi.wav", "rb") as f:
            st = c.post("/api/voice/stt", files={"audio": ("spoken_hi.wav", f, "audio/wav")},
                        data={"mode": "transcribe"})
        print("transcript:", st.json().get("transcript"))

    step("ask a follow-up question")
    ans = c.post("/api/ask", json={"question": "मेरी मिट्टी में नाइट्रोजन कम है, क्या करूँ?",
                                   "sample_id": sid, "crop": "Paddy", "language": "hi-IN"}).json()
    print("answer:", ans.get("text", "")[:500])

    step("record lab status")
    st = c.post(f"/api/samples/{sid}/status", json={"status": "sent_to_lab",
                                                    "note": "Dispatched to district lab"}).json()
    print("status log entries:", len(st["status_log"]))

    step("printable report")
    pr = c.get(f"/api/report/{sid}/print?language=hi-IN")
    print("http:", pr.status_code, "bytes:", len(pr.text))
    (ART / "printable_report_hi.html").write_text(pr.text, encoding="utf-8")

    print("\nALL STEPS COMPLETED. Artifacts in data/artifacts/")


if __name__ == "__main__":
    main()
