"""Deterministic tests for the validation and interpretation rules.

Run:  python -m pytest tests/ -q      (or)   python tests/test_validators.py
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.advisory.interpreter import interpret
from app.soil.parse import parse_digitised
from app.soil.validators import classify, plausibility, validate_extraction


def test_classify_ph_general():
    assert classify("ph", 5.0)["category"] == "strongly_acidic"
    assert classify("ph", 6.0)["category"] == "acidic"
    assert classify("ph", 7.0)["category"] == "neutral"
    assert classify("ph", 8.0)["category"] == "alkaline"


def test_classify_ph_crop_window():
    r = classify("ph", 5.6, crop="Paddy (Kharif)")
    assert r["category"] == "suitable_for_crop" and r["crop_match"] is True
    r2 = classify("ph", 8.2, crop="Wheat")
    assert r2["category"] == "outside_crop_window" and r2["crop_match"] is False


def test_nutrient_bands():
    assert classify("nitrogen", 198)["category"] == "low"
    assert classify("phosphorus", 14)["category"] == "medium"
    assert classify("potassium", 92)["category"] == "low"
    assert classify("organic_carbon", 0.38)["category"] == "low"
    assert classify("zinc", 0.42)["category"] == "low"


def test_plausibility_rejects_impossible():
    assert plausibility("ph", 5.6)[0] is True
    assert plausibility("ph", 25.0)[0] is False
    assert plausibility("nitrogen", 99999)[0] is False


def test_validate_flags_missing_and_implausible():
    ext = {"values": {"ph": 5.6, "ec": 0.21, "organic_carbon": 0.38,
                      "nitrogen": 198, "phosphorus": 14, "potassium": 92, "zinc": 999},
           "confidence": {"ph": {"confidence": 0.5}}}
    v = validate_extraction(ext)
    assert "ph" in v["values"] and "zinc" not in v["values"]
    levels = {f["level"] for f in v["flags"]}
    assert "implausible" in levels and "low_confidence" in levels


def test_parse_digitised_table():
    md = ("<table><tr><td>Available Nitrogen (N)</td><td>198</td><td>kg/ha</td></tr>"
          "<tr><td>pH (1:2.5)</td><td>5.6</td><td></td></tr></table>"
          "Farmer Name: Ramesh Kumar")
    p = parse_digitised(md)
    assert p["values"]["nitrogen"] == 198
    assert p["values"]["ph"] == 5.6
    assert p["units"]["nitrogen"] == "kg/ha"
    assert p["metadata"]["farmer_name"] == "Ramesh Kumar"


def test_interpreter_summary():
    interp = interpret({"ph": 5.6, "nitrogen": 198, "potassium": 92}, {}, "Paddy")
    assert "nitrogen" in interp["summary"]["low"]
    assert interp["summary"]["needs_expert"] is True


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print("ok:", fn.__name__)
    print(f"\n{len(fns)} tests passed.")
